using System.Net;
using System.Text;
using System.Text.Json;
using Hvylia.Api.Models;
using Hvylia.Api.Services;
using Xunit;

namespace Hvylia.Tests;

public class AnalyzeServiceTests
{
    private sealed class FakeHandler : HttpMessageHandler
    {
        private readonly HttpStatusCode _code; private readonly string _body;
        public HttpRequestMessage? Last; public string? LastBody;
        public FakeHandler(HttpStatusCode code, string body = "{}") { _code = code; _body = body; }
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage r, CancellationToken ct)
        {
            Last = r; LastBody = r.Content is null ? null : await r.Content.ReadAsStringAsync(ct);
            return new HttpResponseMessage(_code) { Content = new StringContent(_body, Encoding.UTF8, "application/json") };
        }
    }

    private static AnalyzeService Svc(FakeHandler h) =>
        new(new HttpClient(h), new GeminiSettings(), new SystemPrompt("SYS"));

    private static AnalyzeRequest Req(string key = "k", string json = "{\"a\":1}") =>
        new(key, JsonDocument.Parse(json).RootElement.Clone());

    private const string Ok = "{\"candidates\":[{\"content\":{\"parts\":[{\"text\":\"Привіт, \"},{\"text\":\"світ\"}]}}]}";

    [Fact]
    public async Task EmptyKey_Returns400()
    {
        var r = await Svc(new FakeHandler(HttpStatusCode.OK, Ok)).AnalyzeAsync(Req(key: " "), default);
        Assert.Equal(400, r.Status);
    }

    [Fact]
    public async Task MissingData_Returns400()
    {
        var r = await Svc(new FakeHandler(HttpStatusCode.OK, Ok)).AnalyzeAsync(new AnalyzeRequest("k", null), default);
        Assert.Equal(400, r.Status);
    }

    [Fact]
    public async Task TooLargeData_Returns400()
    {
        var big = "{\"x\":\"" + new string('a', 200 * 1024) + "\"}";
        var r = await Svc(new FakeHandler(HttpStatusCode.OK, Ok)).AnalyzeAsync(Req(json: big), default);
        Assert.Equal(400, r.Status);
    }

    [Fact]
    public async Task Success_JoinsParts_SendsKeyHeader_AndWrapsDataInTags()
    {
        var h = new FakeHandler(HttpStatusCode.OK, Ok);
        var r = await Svc(h).AnalyzeAsync(Req(key: "SECRET"), default);

        Assert.True(r.Ok);
        Assert.Equal("Привіт, світ", r.Text);
        Assert.Equal("SECRET", h.Last!.Headers.GetValues("x-goog-api-key").Single());
        Assert.DoesNotContain("SECRET", h.Last.RequestUri!.ToString());
        Assert.Contains("<data>{\\\"a\\\":1}</data>", h.LastBody);
        Assert.Contains("\"temperature\":0.2", h.LastBody);
        Assert.Contains("\"systemInstruction\"", h.LastBody);
    }

    [Theory]
    [InlineData(HttpStatusCode.BadRequest, 401)]
    [InlineData(HttpStatusCode.Forbidden, 401)]
    [InlineData(HttpStatusCode.TooManyRequests, 429)]
    [InlineData(HttpStatusCode.InternalServerError, 502)]
    public async Task GeminiErrors_AreMapped(HttpStatusCode gemini, int expected)
    {
        var r = await Svc(new FakeHandler(gemini)).AnalyzeAsync(Req(), default);
        Assert.False(r.Ok);
        Assert.Equal(expected, r.Status);
        Assert.False(string.IsNullOrWhiteSpace(r.Error));
    }

    [Fact]
    public async Task EmptyCandidates_Returns502()
    {
        var r = await Svc(new FakeHandler(HttpStatusCode.OK, "{\"candidates\":[]}")).AnalyzeAsync(Req(), default);
        Assert.Equal(502, r.Status);
    }
}
