using System.Text.Json;

namespace Hvylia.Api.Models;

/// <summary>Тіло POST /api/analyze: ключ Gemini користувача + довільний JSON з даними.</summary>
public sealed record AnalyzeRequest(string? ApiKey, JsonElement? Data);

/// <summary>Налаштування виклику Gemini (appsettings.json → "Gemini").</summary>
public sealed class GeminiSettings
{
    public string BaseUrl { get; set; } = "https://generativelanguage.googleapis.com/v1beta/models";
    public string Model { get; set; } = "gemini-2.5-flash";
    public double Temperature { get; set; } = 0.2;
    public int TimeoutSeconds { get; set; } = 60;
    public int MaxDataBytes { get; set; } = 100 * 1024; // 100 КБ
}

public sealed record AnalyzeResult(bool Ok, int Status, string? Text, string? Error)
{
    public static AnalyzeResult Success(string text) => new(true, 200, text, null);
    public static AnalyzeResult Fail(int status, string error) => new(false, status, null, error);
}
