using System.Net;
using System.Text;
using System.Text.Json;
using Hvylia.Api.Models;

namespace Hvylia.Api.Services;

/// <summary>Системний промпт: живе лише на бекенді (Prompts/analyze_system.txt).</summary>
public sealed class SystemPrompt
{
    public string Text { get; }
    public SystemPrompt(string text) => Text = text;

    public static SystemPrompt Load(string path) =>
        new(File.Exists(path)
            ? File.ReadAllText(path, Encoding.UTF8)
            : "Ти аналітик. Проаналізуй дані в тегах <data></data>. Відповідай українською.");
}

/// <summary>Складає запит до Gemini, викликає його та мапить помилки. Ключ і тіло запиту не логуються.</summary>
public sealed class AnalyzeService
{
    private readonly HttpClient _http;
    private readonly GeminiSettings _s;
    private readonly SystemPrompt _prompt;

    public AnalyzeService(HttpClient http, GeminiSettings settings, SystemPrompt prompt)
    {
        _http = http; _s = settings; _prompt = prompt;
    }

    public async Task<AnalyzeResult> AnalyzeAsync(AnalyzeRequest? req, CancellationToken ct)
    {
        // 1. Валідація
        if (req is null || string.IsNullOrWhiteSpace(req.ApiKey))
            return AnalyzeResult.Fail(400, "Не вказано API-ключ");
        if (req.Data is not { } data || data.ValueKind is JsonValueKind.Undefined or JsonValueKind.Null)
            return AnalyzeResult.Fail(400, "Немає даних для аналізу");

        var dataJson = data.GetRawText();
        if (Encoding.UTF8.GetByteCount(dataJson) > _s.MaxDataBytes)
            return AnalyzeResult.Fail(400, $"Дані завеликі (максимум {_s.MaxDataBytes / 1024} КБ)");

        // 2. Запит до Gemini
        var url = $"{_s.BaseUrl.TrimEnd('/')}/{_s.Model}:generateContent";
        using var msg = new HttpRequestMessage(HttpMethod.Post, url)
        {
            Content = new StringContent(BuildBody(_prompt.Text, dataJson, _s.Temperature), Encoding.UTF8, "application/json")
        };
        msg.Headers.TryAddWithoutValidation("x-goog-api-key", req.ApiKey.Trim());

        using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        cts.CancelAfter(TimeSpan.FromSeconds(_s.TimeoutSeconds));

        try
        {
            using var resp = await _http.SendAsync(msg, cts.Token);
            if (!resp.IsSuccessStatusCode) return MapError(resp.StatusCode);

            var raw = await resp.Content.ReadAsStringAsync(cts.Token);
            var text = ExtractText(raw);
            return string.IsNullOrWhiteSpace(text)
                ? AnalyzeResult.Fail(502, "Gemini повернув порожню відповідь")
                : AnalyzeResult.Success(text);
        }
        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
        {
            return AnalyzeResult.Fail(502, "Gemini не відповів вчасно (таймаут)");
        }
        catch (HttpRequestException)
        {
            return AnalyzeResult.Fail(502, "Не вдалося звернутися до Gemini");
        }
        catch (JsonException)
        {
            return AnalyzeResult.Fail(502, "Gemini повернув некоректну відповідь");
        }
    }

    /// <summary>Тіло: systemInstruction + contents (&lt;data&gt;…&lt;/data&gt;) + generationConfig.</summary>
    public static string BuildBody(string systemPrompt, string dataJson, double temperature) =>
        JsonSerializer.Serialize(new
        {
            systemInstruction = new { parts = new[] { new { text = systemPrompt } } },
            contents = new[]
            {
                new { role = "user", parts = new[] { new { text = $"<data>{dataJson}</data>" } } }
            },
            generationConfig = new { temperature }
        });

    /// <summary>candidates[0].content.parts[*].text → один рядок.</summary>
    public static string ExtractText(string rawJson)
    {
        using var doc = JsonDocument.Parse(rawJson);
        if (!doc.RootElement.TryGetProperty("candidates", out var cands)
            || cands.ValueKind != JsonValueKind.Array || cands.GetArrayLength() == 0) return "";

        if (!cands[0].TryGetProperty("content", out var content)
            || !content.TryGetProperty("parts", out var parts)
            || parts.ValueKind != JsonValueKind.Array) return "";

        var sb = new StringBuilder();
        foreach (var p in parts.EnumerateArray())
            if (p.TryGetProperty("text", out var t) && t.ValueKind == JsonValueKind.String)
                sb.Append(t.GetString());
        return sb.ToString();
    }

    public static AnalyzeResult MapError(HttpStatusCode code) => (int)code switch
    {
        400 or 403 => AnalyzeResult.Fail(401, "Невірний API-ключ"),
        429        => AnalyzeResult.Fail(429, "Перевищено ліміт запитів до Gemini, спробуйте пізніше"),
        _          => AnalyzeResult.Fail(502, "Сервіс Gemini тимчасово недоступний")
    };
}
